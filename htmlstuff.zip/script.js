document.addEventListener("click", function() { 
    var hiddenText = document.getElementById("anybutton"); 
    console.log;
  }); 